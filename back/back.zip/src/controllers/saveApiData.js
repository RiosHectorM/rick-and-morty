const axios = require('axios');
const { character } = require('../models/Character.js');

const getApiData = async () => {
  let resp100 = [];
  const URL = 'https://rickandmortyapi.com/api/character/';

  try {
    console.log('entro a getapidata');
    for (let i = 1; i <= 10; i++) {
      console.log(i);
      const response = await axios(`${URL}${i}`);
      const data = await response.data;
      let char = {
        id: data.id,
        image: data.image,
        name: data.name,
        gender: data.gender,
        species: data.species,
        origin: data.origin.name,
        location: data.location.name,
      };
      resp100.push(char);
    }
    console.log(resp100.length);
    return resp100;
  } catch (error) {
    return [];
  }
};

const saveApiData = async (req, res) => {
  const characters100 = await getApiData();

  console.log(characters100);

  characters100.forEach(async (element) => {
    try {
      const asdasd = await character.findOrCreate({
        where: {
          id: element.id,
          name: element.name,
          species: element.species,
          status: element.status,
          gender: element.gender,
          origin: element.origin,
          imagen: element.imagen,
        },
      });
      console.log(asdasd)
    } catch (err) {
      console.log(err.message);
    }
  });
};

module.exports = saveApiData;
