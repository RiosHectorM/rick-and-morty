const favorites = []

module.exports = favorites;